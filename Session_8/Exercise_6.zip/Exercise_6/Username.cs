using System;

namespace WebAPIClient
{
    public class Username
    {
        public int id;
        public string name;
        public string email;
    }
}